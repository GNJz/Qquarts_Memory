# Qquarts_Memory
